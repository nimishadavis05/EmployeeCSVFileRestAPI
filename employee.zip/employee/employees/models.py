from django.db import models

# Create your models here.

class File(models.Model):
	employee_code=models.CharField(max_length=120,unique=True)
	employee_name=models.CharField(max_length=230)
	department=models.CharField(max_length=120)
	age=models.IntegerField()
	org_experience=models.FloatField()
	def __str__(self):
		return self.employee_code