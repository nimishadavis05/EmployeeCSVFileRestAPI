from django.http import Http404
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from .serializers import FileUploadSerializer,SaveFileSerializer
from .models import File
from django.shortcuts import render
from rest_framework import generics
import io, csv, pandas as pd

#upload file 
class UploadFileView(generics.CreateAPIView):
    serializer_class = FileUploadSerializer
    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        file = serializer.validated_data['file']
        reader = pd.read_csv(file, on_bad_lines='skip')
        for _, row in reader.iterrows():
            new_file = File(
                       employee_code = row['Employee Code'],
                       employee_name= row['Employee Name'],
                       department= row['Department'],
                       age= row['Age'],
                       org_experience= row['Experience in this Organisation']
                       )
            new_file.save()
        return Response({"status": "success"},
                        status.HTTP_201_CREATED)

#view employee details
class Employee(APIView):
	model=File
	permission_classes=[IsAuthenticated]
	authentication_classes=(TokenAuthentication,)
	def get(self,request):
		files=File.objects.all()
		serializer=SaveFileSerializer(files,many=True)
		return Response(serializer.data)

	def post(self,request):
		serializer=SaveFileSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return Response(serializer.data,status=status.HTTP_201_CREATED)
		else:
			return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
