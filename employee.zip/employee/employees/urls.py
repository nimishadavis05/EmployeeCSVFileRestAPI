
from django.urls import path
from .views import UploadFileView,Employee
from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework.authtoken import views
urlpatterns = [
    path("employee/",Employee.as_view(),name="employee"),
    path('upload/', UploadFileView.as_view(), name='upload-file'),
   
    
]
