from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from .models import File
from rest_framework import exceptions


class FileUploadSerializer(serializers.Serializer):
	file  = serializers.FileField()

class SaveFileSerializer(ModelSerializer):	
	class Meta:
		model=File
		fields="__all__"
	def validate(self,data):
		print(data)
		return data
