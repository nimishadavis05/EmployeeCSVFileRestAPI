from django.contrib import admin
from .models import File
# Register your models here.
class FileAdmin(admin.ModelAdmin):
    list_display=["employee_code","employee_name","department","age","org_experience"]
admin.site.register(File, FileAdmin)  

 